@echo off
setlocal
echo ==========================================================
echo           DIGITAL SWARM: swarm-property UPLINK
echo ==========================================================
echo [STATUS] INITIALIZING AI AGENT ARCHITECTURE...

:: Check for Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python not found. Please install Python from: https://www.python.org/
    pause
    exit /b
)

:: Activate and run
echo [STATUS] UPLINK ESTABLISHED. LAUNCHING DASHBOARD...
python -m pip install -r requirements.txt --quiet
python ai_real_estate_agent_team.py
pause
