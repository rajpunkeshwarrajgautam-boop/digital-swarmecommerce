# Swarm Video-Gen Oracle

An advanced, multi-agent AI framework designed to intelligently structure, write, and produce high-retention video content for YouTube, TikTok, and Instagram.

## How to Start (No Coding Required)

1. **Extract** this ZIP folder to your desktop.
2. **Double-click** the `LAUNCH.bat` file. 
3. The system will automatically download the necessary dependencies and open the Oracle Dashboard in your web browser.
4. Input your **Google Gemini API Key** (You can get a free one from Google AI Studio).
5. Generate end-to-end video production documents!

*A premium tool by [Digital Swarm](https://digitalswarm.in).*
