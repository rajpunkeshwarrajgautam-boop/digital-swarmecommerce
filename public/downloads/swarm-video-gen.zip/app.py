# Import the required libraries
import streamlit as st
from agno.agent import Agent
from agno.run.agent import RunOutput
from agno.team import Team
from agno.tools.serpapi import SerpApiTools
from agno.models.google import Gemini
from textwrap import dedent

# Set up the Streamlit app with Digital Swarm Styling
st.set_page_config(page_title="Swarm Video-Gen Oracle", page_icon="🎬", layout="centered")

st.markdown("""
<style>
    .stApp { background-color: #0A0A0B; color: #E2E8F0; }
    h1 { color: #00F0FF !important; font-family: monospace; text-transform: uppercase; letter-spacing: 2px;}
    .stTextInput>div>div>input { background-color: #1A1A1A; color: #00F0FF; border: 1px solid #333;}
    .stButton>button { width: 100%; border-radius: 4px; background-color: #00F0FF; color: #000; font-weight: bold; border: none; }
    .stButton>button:hover { background-color: #00C0CC; }
</style>
""", unsafe_allow_html=True)

st.title("SWARM VIDEO-GEN ORACLE 🎬")
st.caption("Autonomous Video Script & Production Intelligence Matrix (Powered by Gemini)")

# API Keys
col1, col2 = st.columns(2)
with col1:
    google_api_key = st.text_input("Gemini API Key (Required)", type="password")
with col2:
    serp_api_key = st.text_input("SerpAPI Key (Optional / Real-time Data)", type="password")

st.markdown("---")

if google_api_key:
    # 1. Scriptwriter Agent
    script_writer = Agent(
        name="ContentArchitect",
        model=Gemini(id="gemini-2.5-flash", api_key=google_api_key),
        description=dedent(
            """\
        You are an elite, high-retention video scriptwriter designed to maximize YouTube/TikTok engagement.
        Given a video concept, develop a high-retention script outline, hook, and pacing structure.
        """
        ),
        instructions=[
            "Start with a highly aggressive, curiosity-driven 5-second Hook.",
            "Outline the video into 3 distinct acts to maintain viewer retention.",
            "Provide B-Roll and visual asset suggestions alongside the script.",
            "Write in a fast-paced, direct, and authoritative tone."
        ],
    )

    # 2. Production Manager Agent
    tools_list = [SerpApiTools(api_key=serp_api_key)] if serp_api_key else []
    
    production_manager = Agent(
        name="ProductionManager",
        model=Gemini(id="gemini-2.5-flash", api_key=google_api_key),
        description=dedent(
            """\
        You are a highly analytical production manager. Review the script and provide technical asset requirements.
        If a SerpAPI key is provided, search for current trends related to the topic.
        """
        ),
        instructions=[
            "Identify the exact Midjourney prompts or Stock Video keywords needed for the B-Roll.",
            "Suggest an SEO-optimized YouTube Title and 3 highly clickable Thumbnail concepts.",
            "Identify what equipment (Camera/Mic) or software (CapCut/Premiere) is required to execute this.",
        ],
        tools=tools_list,
    )

    # Team Swarm
    video_oracle = Team(
        name="VideoOracleTeam",
        model=Gemini(id="gemini-2.5-flash", api_key=google_api_key),
        members=[script_writer, production_manager],
        description="A specialized AI swarm orchestrating end-to-end algorithmic video production.",
        instructions=[
            "Ask ContentArchitect to write the script, hook, and outline.",
            "Pass the script to ProductionManager to generate Thumbnails, Titles, and B-Roll prompts.",
            "Synthesize everything into a final, highly readable 'Master Production Document'.",
        ],
        markdown=True,
    )

    # Input Matrix
    video_idea = st.text_area("TARGET CONCEPT (Enter your video idea or topic):", height=100)
    
    col3, col4 = st.columns(2)
    with col3:
        platform = st.selectbox("PLATFORM:", ["YouTube (Long-Form)", "YouTube Shorts", "TikTok", "Instagram Reels"])
    with col4:
        vibe = st.selectbox("AESTHETIC / VIBE:", ["Documentary / Cinematic", "High-Energy / Fast-Paced", "Educational / Talking Head", "Faceless / AI-Generated"])

    if st.button("INITIALIZE GENERATION SEQUENCE"):
        if not video_idea:
            st.error("SYSTEM ERROR: Target Concept required.")
        else:
            with st.spinner("SYNTHESIZING PRODUCTION MATRIX..."):
                input_text = (
                    f"Core Idea: {video_idea}\n"
                    f"Platform: {platform}\n"
                    f"Aesthetic: {vibe}\n"
                )
                response: RunOutput = video_oracle.run(input_text, stream=False)
                st.success("SEQUENCE COMPLETE.")
                st.markdown("### 🗂️ MASTER PRODUCTION DOCUMENT")
                st.markdown(response.content)
else:
    st.warning("SYSTEM LOCK: Please inject your Gemini API Key to initialize the Oracle.")
