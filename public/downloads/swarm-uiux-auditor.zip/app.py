import streamlit as st
import tempfile
import os
from PIL import Image
from agno.agent import Agent
from agno.run.agent import RunOutput
from agno.models.google import Gemini
from textwrap import dedent

# Digital Swarm Aesthetic Configuration
st.set_page_config(page_title="Swarm Vision Auditor", page_icon="👁️", layout="wide")

st.markdown("""
<style>
    .stApp { background-color: #030712; color: #E2E8F0; }
    h1 { color: #A855F7 !important; font-family: monospace; text-transform: uppercase; letter-spacing: 2px;}
    .stTextInput>div>div>input { background-color: #111; color: #A855F7; border: 1px solid #333;}
    .stButton>button { width: 100%; border-radius: 4px; background-color: #A855F7; color: #FFF; font-weight: bold; border: none; letter-spacing: 1px;}
    .stButton>button:hover { background-color: #9333EA; }
    .stFileUploader>div>div { background-color: #111; border: 1px solid #333;}
</style>
""", unsafe_allow_html=True)

st.title("SWARM UI/UX VISION AUDITOR 👁️")
st.caption("Autonomous Multimodal Design Analysis & Conversion Teardown (Powered by Gemini Vision)")

# API Authorization
google_api_key = st.text_input("Gemini API Key (System Authorization)", type="password")
st.markdown("---")

if google_api_key:
    # Vision Agent
    vision_agent = Agent(
        name="DesignOracle",
        model=Gemini(id="gemini-2.5-flash", api_key=google_api_key),
        description=dedent(
            """\
        You are a highly paid, ruthless Senior Product Designer and Conversion Optimization expert. 
        Analyze the provided screenshot with extreme precision. Don't be too nice; focus on what kills conversions.
        """
        ),
        instructions=[
            "Provide an exact heuristic score out of 100.",
            "Analyze Typography, Visual Hierarchy, Spacing, and Color Contrast.",
            "Identify exactly where the 'Call To Action' fails.",
            "Provide a step-by-step redesign prescription to fix the errors."
        ],
        markdown=True
    )

    st.markdown("### TARGET TELEMETRY")
    uploaded_file = st.file_uploader("Upload UI Screenshot (PNG/JPG)", type=['png', 'jpg', 'jpeg'])

    if st.button("INITIALIZE VISION AUDIT SEQUENCE"):
        if not uploaded_file:
            st.error("SYSTEM ERROR: Valid UI Screenshot required.")
        else:
            with st.spinner("ANALYZING PIXELS. EXTRACTING CONVERSION LOOPHOLES..."):
                # Read image
                image = Image.open(uploaded_file)
                st.image(image, caption="Target User Interface", use_container_width=True)

                # Process Vision Task
                payload = "Analyze this UI screenshot thoroughly based on your instructions."
                
                # Gemini automatically accepts images passed in the run() method list payload in Agno
                try:
                    # Save temp image for the agent
                    with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as temp_file:
                        image.save(temp_file.name)
                        temp_path = temp_file.name

                    # Send to Agent (Agno supports multimodality by passing the path in a dict or wrapping)
                    # For a robust approach, we just pass the image file or PIL image if supported by the adapter.
                    response: RunOutput = vision_agent.run(
                        "Analyze this UI. Be ruthless.",
                        images=[temp_path],
                        stream=False
                    )
                    
                    # Cleanup
                    os.unlink(temp_path)

                    st.success("AUDIT COMPLETE.")
                    st.markdown("### 🗂️ DIAGNOSTIC REPORT")
                    st.markdown(response.content)

                except Exception as e:
                    st.error(f"MATRIX FAILURE: {str(e)}")
                    st.error("Ensure you have raw `google-generativeai` installed and correct API keys.")
else:
    st.warning("SYSTEM LOCK: A valid Gemini API Key is required to activate the Vision module.")
