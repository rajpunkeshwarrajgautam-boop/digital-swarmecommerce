# Swarm UI/UX Vision Auditor

A highly sophisticated multimodal agent that scans screenshots of your website or app and provides a ruthless teardown to maximize your conversion rate.

## How to Start (No Coding Required)

1. **Extract** this ZIP folder to your desktop.
2. **Double-click** the `LAUNCH.bat` file. 
3. The system will automatically download the necessary dependencies and open the Oracle Dashboard in your web browser.
4. Input your **Google Gemini API Key** (You can get a free one from Google AI Studio).
5. Drag and drop a screenshot and let the Oracle audit your design!

*A premium tool by [Digital Swarm](https://digitalswarm.in).*
