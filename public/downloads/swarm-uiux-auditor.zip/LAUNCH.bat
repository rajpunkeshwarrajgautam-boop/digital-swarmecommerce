@echo off
title SWARM VISION AUDITOR - BOOT SEQUENCE
color 05

echo ===================================================
echo   DIGITAL SWARM: VISION AUDITOR INITIALIZATION
echo ===================================================
echo.
echo [SYSTEM] Verifying Python environment...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed. Please install Python 3.10+ and add it to your PATH.
    pause
    exit /b
)

echo [SYSTEM] Installing neural dependencies...
pip install -r requirements.txt -q

echo [SYSTEM] Dependencies verified.
echo [SYSTEM] Launching Vision Interface...
echo.

streamlit run app.py

pause
