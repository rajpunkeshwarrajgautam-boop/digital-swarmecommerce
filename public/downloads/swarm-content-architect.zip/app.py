import streamlit as st
from agno.agent import Agent
from agno.run.agent import RunOutput
from agno.team import Team
from agno.tools.serpapi import SerpApiTools
from agno.models.google import Gemini
from textwrap import dedent

# Digital Swarm Aesthetic Configuration
st.set_page_config(page_title="Swarm Content Architect", page_icon="📝", layout="wide")

st.markdown("""
<style>
    .stApp { background-color: #050505; color: #E2E8F0; }
    h1 { color: #FF0055 !important; font-family: monospace; text-transform: uppercase; letter-spacing: 2px;}
    .stTextInput>div>div>input { background-color: #111; color: #FF0055; border: 1px solid #333;}
    .stButton>button { width: 100%; border-radius: 4px; background-color: #FF0055; color: #FFF; font-weight: bold; border: none; letter-spacing: 1px;}
    .stButton>button:hover { background-color: #CC0044; }
</style>
""", unsafe_allow_html=True)

st.title("SWARM CONTENT ARCHITECT 📝")
st.caption("Autonomous 30-Day B2B Social Media Matrix Generator (Powered by Gemini)")

# API Authorization
col1, col2 = st.columns(2)
with col1:
    google_api_key = st.text_input("Gemini API Key (System Authorization)", type="password")
with col2:
    serp_api_key = st.text_input("SerpAPI Key (Optional / Real-time Competitor Intel)", type="password")

st.markdown("---")

if google_api_key:
    # 1. Spy Agent
    intel_agent = Agent(
        name="TargetIntelligence",
        model=Gemini(id="gemini-2.5-flash", api_key=google_api_key),
        description="You are a corporate espionage and data analysis agent. Your goal is to analyze the target industry and extract the most viral topics.",
        instructions=[
            "Analyze the target industry.",
            "Identify 5 high-converting, viral topics or pain points.",
            "Provide statistical or trending context for these topics.",
        ],
        tools=[SerpApiTools(api_key=serp_api_key)] if serp_api_key else [],
    )

    # 2. Viral Ghostwriter Agent
    ghost_writer = Agent(
        name="ViralGhostwriter",
        model=Gemini(id="gemini-2.5-flash", api_key=google_api_key),
        description="You are a 7-figure LinkedIn and X (Twitter) ghostwriter. You write aggressive, highly authoritative B2B content.",
        instructions=[
            "Take the trending topics and generate a precise 30-Day Content Calendar schedule.",
            "Write exactly 3 complete, full-text posts (including strong curiosity hooks) as examples.",
            "Utilize short, punchy sentences. Avoid fluff.",
            "Generate 5 high-impact visual suggestions (Carousels/Infographics) to accompany the output."
        ],
    )

    # Core 30-Day Content Team
    content_swarm = Team(
        name="ContentOracleTeam",
        model=Gemini(id="gemini-2.5-flash", api_key=google_api_key),
        members=[intel_agent, ghost_writer],
        description="A specialized dual-agent matrix that audits an industry and churns out 30 days of high-converting social media content.",
        instructions=[
            "Command TargetIntelligence to audit the specific Industry and Competitor.",
            "Pass those high-converting topics to ViralGhostwriter.",
            "Output the final 30-Day Content Matrix with example texts and visual cues.",
        ],
        markdown=True,
    )

    # Telemetry Input
    st.markdown("### TARGET PARAMETERS")
    target_industry = st.text_input("Industry / Niche (e.g., 'B2B SaaS', 'Real Estate Tech'):")
    target_audience = st.text_input("Target Audience (e.g., 'CMOs', 'Indie Hackers'):")
    tone = st.selectbox("Content Tone:", ["Aggressive / Authoritative", "Educational / Helpful", "Controversial / Polarizing", "Story-Driven"])

    if st.button("INITIALIZE 30-DAY CONTENT MATRIX"):
        if not target_industry or not target_audience:
            st.error("SYSTEM ERROR: Niche and Audience parameters are required.")
        else:
            with st.spinner("INITIATING AGENT SWARM. GATHERING INTEL..."):
                payload = (
                    f"Industry: {target_industry}\n"
                    f"Audience: {target_audience}\n"
                    f"Required Tone: {tone}\n"
                    "Command: Execute full audit and generate 30-day matrix."
                )
                response: RunOutput = content_swarm.run(payload, stream=False)
                st.success("MATRIX GENERATION COMPLETE.")
                st.markdown("### 🗂️ 30-DAY CONTENT STRATEGY")
                st.markdown(response.content)
else:
    st.warning("SYSTEM LOCK: A valid Gemini API Key is required to power the Swarm.")
