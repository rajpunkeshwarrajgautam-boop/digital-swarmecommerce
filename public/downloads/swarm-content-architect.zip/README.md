# Swarm Content Architect

An authoritative B2B multi-agent swarm that researches your industry, extracts high-converting ideas, and writes 30 days of absolute killer LinkedIn/Twitter content.

## How to Start (No Coding Required)

1. **Extract** this ZIP folder to your desktop.
2. **Double-click** the `LAUNCH.bat` file. 
3. The system will automatically download the necessary dependencies and open the Oracle Dashboard in your web browser.
4. Input your **Google Gemini API Key** (You can get a free one from Google AI Studio).
5. Generate end-to-end 30-day social media matrices!

*A premium tool by [Digital Swarm](https://digitalswarm.in).*
